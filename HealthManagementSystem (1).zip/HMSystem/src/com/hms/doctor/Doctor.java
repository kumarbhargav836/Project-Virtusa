package com.hms.doctor;

public class Doctor {
	private String did, dname, specialist, appoint, doc_qual;
    private int droom;
	public String getDid() {
		return did;
	}
	public void setDid(String did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getSpecialist() {
		return specialist;
	}
	public void setSpecialist(String specilist) {
		this.specialist = specilist;
	}
	public String getAppoint() {
		return appoint;
	}
	public void setAppoint(String appoint) {
		this.appoint = appoint;
	}
	public String getDoc_qual() {
		return doc_qual;
	}
	public void setDoc_qual(String doc_qual) {
		this.doc_qual = doc_qual;
	}
	public int getDroom() {
		return droom;
	}
	public void setDroom(int droom) {
		this.droom = droom;
	}
    
    
}
